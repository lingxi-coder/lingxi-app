window.LINGXI_BRAND = {
  "version": "1.1.0",
  "status": "integrated",
  "name": "星芒 / Sparkles",
  "brand": {
    "en": "LingXi",
    "zh-Hans": "灵犀",
    "zh-Hant": "靈犀",
    "bilingual": "灵犀 LingXi"
  },
  "colors": {
    "primary": "#4167ED",
    "ink": "#202632",
    "paper": "#F6F5F0",
    "white": "#FFFFFF"
  },
  "geometry": {
    "viewBox": [
      0,
      0,
      128,
      128
    ],
    "path": "M52 32L62 54L84 64L62 74L52 96L42 74L20 64L42 54ZM92 20L97 31L108 36L97 41L92 52L87 41L76 36L87 31ZM92 76L97 87L108 92L97 97L92 108L87 97L76 92L87 87Z",
    "rotation": 0,
    "fill": "solid"
  },
  "products": [
    {
      "id": "code",
      "en": "LingXi Code",
      "zh": "灵犀 Code",
      "launcher_en": "LingXi",
      "launcher_zh": "灵犀",
      "descriptor": "Code",
      "color": "#4167ED",
      "role": "product",
      "purpose": "把想法变成作品",
      "source": "lingxi-app"
    },
    {
      "id": "chat",
      "en": "LingXi Chat",
      "zh": "灵犀聊天",
      "launcher_en": "LingXi Chat",
      "launcher_zh": "灵犀聊天",
      "descriptor": "Chat",
      "color": "#137C70",
      "role": "product",
      "purpose": "让交流自然发生",
      "source": "chat"
    },
    {
      "id": "computer-use",
      "en": "LingXi Control",
      "zh": "灵犀操控",
      "launcher_en": "LingXi Control",
      "launcher_zh": "灵犀操控",
      "descriptor": "Control",
      "color": "#6653B9",
      "role": "product",
      "purpose": "让意图化为行动",
      "source": "computer-use"
    },
    {
      "id": "apps",
      "en": "LingXi Apps",
      "zh": "灵犀应用",
      "launcher_en": "LingXi Apps",
      "launcher_zh": "灵犀应用",
      "descriptor": "Apps",
      "color": "#AF5B2F",
      "role": "product",
      "purpose": "发现触手可及的工具",
      "source": "local-app-market"
    },
    {
      "id": "remote",
      "en": "LingXi Remote",
      "zh": "灵犀远控",
      "launcher_en": null,
      "launcher_zh": null,
      "descriptor": "Remote",
      "color": "#1F728F",
      "role": "feature",
      "purpose": "随时连接你的设备",
      "source": "lingxi-app / Remote Control"
    },
    {
      "id": "harness",
      "en": "LingXi Harness",
      "zh": "灵犀 Harness",
      "launcher_en": null,
      "launcher_zh": null,
      "descriptor": "Harness",
      "color": "#4F5B69",
      "role": "developer",
      "purpose": "代理运行时",
      "source": "harness-runtime"
    },
    {
      "id": "sdk",
      "en": "LingXi SDK",
      "zh": "灵犀 SDK",
      "launcher_en": null,
      "launcher_zh": null,
      "descriptor": "SDK",
      "color": "#5B6553",
      "role": "developer",
      "purpose": "构建与接入",
      "source": "SDK family"
    }
  ],
  "developer_labels": [
    {
      "en": "LingXi WebRTC",
      "zh": "灵犀 WebRTC",
      "family": "sdk",
      "icon": "sdk"
    },
    {
      "en": "LingXi Mobile Linux",
      "zh": "灵犀 Mobile Linux",
      "family": "sdk",
      "icon": "sdk"
    },
    {
      "en": "LingXi LLM Client",
      "zh": "灵犀 LLM Client",
      "family": "sdk",
      "icon": "sdk"
    }
  ],
  "rules": {
    "wordmark_min_width": 96,
    "mark_min_size": 16,
    "clear_space_mark_units": 20,
    "product_variation": "color-only",
    "same_mark_at_all_sizes": true,
    "small_icon_requires_visible_product_label": true,
    "application_identifiers_changed": false
  }
};
